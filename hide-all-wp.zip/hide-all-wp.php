<?php
/*
Plugin Name: Hide All WP
Description: Oculta todos los avisos de administración en WordPress y proporciona un botón para mostrarlos cuando sea necesario.
Version: 1.0.0
Author: José Oliva
Author URI: https://startmotifmedia.com
License: GPLv2 or later
*/

// Función principal para ocultar avisos de administración y agregar el botón
function hide_all_wp_admin_notices() {
    // Solo para usuarios en el panel de administración
    if (!is_admin()) {
        return;
    }
    ?>
    <style>
        #wp-admin-bar-show_notices {
            display: none;
        }
        .admin-notice-hidden .notice, .admin-notice-hidden .update-nag, .admin-notice-hidden .error, .admin-notice-hidden .updated {
            display: none !important;
        }
    </style>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Crear el botón "Show Notices"
            const showNoticesButton = document.createElement('button');
            showNoticesButton.textContent = 'Show Notices';
            showNoticesButton.style.position = 'fixed';
            showNoticesButton.style.top = '60px'; // Asegurar que no se superponga con la barra de administración
            showNoticesButton.style.right = '10px';
            showNoticesButton.style.zIndex = '9999';
            showNoticesButton.style.padding = '10px';
            showNoticesButton.style.backgroundColor = '#007cba';
            showNoticesButton.style.color = '#fff';
            showNoticesButton.style.border = 'none';
            showNoticesButton.style.borderRadius = '3px';
            showNoticesButton.style.cursor = 'pointer';

            let noticesHidden = true;

            showNoticesButton.addEventListener('click', function() {
                noticesHidden = !noticesHidden;
                if (noticesHidden) {
                    document.body.classList.add('admin-notice-hidden');
                    showNoticesButton.textContent = 'Show Notices';
                } else {
                    document.body.classList.remove('admin-notice-hidden');
                    showNoticesButton.textContent = 'Hide Notices';
                }
            });

            // Insertar el botón en el cuerpo del documento
            document.body.appendChild(showNoticesButton);

            // Ocultar los avisos inicialmente
            document.body.classList.add('admin-notice-hidden');
        });
    </script>
    <?php
}
add_action('admin_footer', 'hide_all_wp_admin_notices');
